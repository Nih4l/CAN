import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import BeforeLoginHome from './Pages/BeforeLoginHome'
import Login from './Pages/Login'
import ChooseTitle from './Pages/ChooseTitle'
import PhoneNumber from './Pages/PhoneNumber'
import Register from './Pages/Register'
import RegisterImage from './Pages/RegisterImage'
import LoginOTP from './Pages/LoginOTP'
import Home from './Pages/Home'
import Test from './Pages/Test'
import CreatePost from './Components/CreatePost'
import ChatPage from './Pages/ChatPage'
import FlippingImage from './Components/FlipImage'
import Meeting from './Pages/Meeting'
import Profile from './Pages/Profile'
import OldUserLogin from './Pages/OldUserLogin'
import OldUserLoginTitle from './Pages/OldUserLoginTitle'
import OldUserRegister from './Pages/OldUserLoginRegister'
import OldUserOTP from './Pages/OldUserOTP'
import OldUserSuccessfully from './Pages/OldUserSuccessfully'
import OldUserPass from './Pages/OldUserPass'
import HealthRecord from './Pages/HealthRecord'
import HealthRecord1 from './Pages/HealthRecord1'
import HealthCard from './Pages/HealthCard'
import HealthCard1 from './Pages/HealthCard1'
import Appointment from './Pages/Appointment'
import Appointment1 from './Pages/Appointment1'
import Password from './Pages/Password'
import MultiPIN from './Pages/MultiPIN'
import LoginForm from './Pages/LoginForm'
import AddProfile from './Pages/AddProfile'


const App = () => {
  return (
    <> 
      <BrowserRouter>
      <Routes>
        
        <Route exact path = '/' element = {<BeforeLoginHome /> }/>
        <Route exact path = 'login' element={<Login />} />
        <Route exact path = 'choosetitle' element={<ChooseTitle />} />
        <Route exact path = 'phonenumber' element={<PhoneNumber />} />
        <Route exact path = 'register' element={<Register />} />
        <Route exact path = 'registerimage' element={<RegisterImage />} />
        <Route exact path = 'loginotp' element={<LoginOTP />} />
        <Route exact path = 'password' element={<Password />} />
        <Route exact path = 'home' element={<Home />} />
        <Route exact path = 'test' element={<Test />} />
        <Route exact path = 'createpost' element={<CreatePost />} />
        <Route exact path = 'chatpage' element={<ChatPage />} />
        <Route exact path = 'meeting' element={<Meeting />} />
        <Route exact path = 'profile' element={<Profile />} />
        <Route exact path = 'LoginForm' element={<LoginForm />} />
        <Route exact path = 'OldUserLogin' element={<OldUserLogin />} />
        <Route exact path = 'OldUserLoginTitle' element={<OldUserLoginTitle />} />
        <Route exact path = 'OldUserRegister' element={<OldUserRegister />} />
        <Route exact path = 'OldUserOTP' element={<OldUserOTP />} />
        <Route exact path = 'OldUserSuccessfully' element={<OldUserSuccessfully />} />
        <Route exact path = 'OldUserPass' element={<OldUserPass />} />
        <Route exact path = 'HealthRecord' element={<HealthRecord />} />
        <Route exact path = 'HealthRecord1' element={<HealthRecord1 />} />
        <Route exact path = 'HealthCard' element={<HealthCard />} />
        <Route exact path = 'HealthCard1' element={<HealthCard1 />} />
        <Route exact path = 'Appointment' element={<Appointment />} />
        <Route exact path = 'Appointment1' element={<Appointment1 />} />
        <Route exact path = 'MultiPIN' element={<MultiPIN />} />
        <Route exact path = 'AddProfile' element={<AddProfile />} />
        
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App