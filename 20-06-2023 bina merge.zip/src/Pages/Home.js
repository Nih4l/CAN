import React, { useEffect, useRef, useState } from 'react'
import HomeNav from '../Components/HomeNav'
import VerticalAppointment from '../Components/VerticalAppointment'
import VerticalMedicine from '../Components/VerticalMedicine'
import account from '../Photos/account.jpg'
import climberEverest from '../Photos/climberEverest.webp'
import premium from '../Photos/premium.png'
import { BsThreeDotsVertical } from 'react-icons/bs'
import { AiOutlineHeart } from 'react-icons/ai'
import { AiFillHeart } from 'react-icons/ai'
import { FaRegComment } from 'react-icons/fa'
import { SlPaperPlane } from 'react-icons/sl'
import { BsBookmarkDash } from 'react-icons/bs'
import { TfiGallery } from 'react-icons/tfi'
import { HiOutlineGif } from 'react-icons/hi2'
import { HiOutlineLocationMarker } from 'react-icons/hi'
import { GrEmoji } from 'react-icons/gr'
import { RiArrowDropDownLine } from 'react-icons/ri'
import SingleLineCalendar from '../Components/SingleLineCalender'
import VerticalSLC from '../Components/VericalSLC'
import FlippingImage from '../Components/FlipImage'
import FloatingChat from '../Components/FloatingChat'
import Page from "../Layouts/Pages";



const Home = () => {

    const [heart, setHeart] = useState()
    const [heart1, setHeart1] = useState()
    const [createPost, setCreatePost] = useState(true)

    function likeButton() {
        setHeart(!heart)
    }
    function likeButton1() {
        setHeart1(!heart1)
    }

    function open_post() {
        setCreatePost(!createPost)
    }

    const para = 'Bethany was running in a half marathon when she began to feel ill. She thought that her celiac disease may have flared up due to something she had eaten, but when she didn’t get better, she decided to see a doctor. What followed was a series of misdiagnoses is the etc'

    // three dots
    const [threeDots, setThreeDots] = useState(false)

    function threeDotsToggle() {
        setThreeDots(!threeDots)
    }

    //outclick from three dots
    const threeDotsOutClick = useRef(null);

    const handleClickOutsidethreeDots = (event) => {
        if (threeDotsOutClick.current && !threeDotsOutClick.current.contains(event.target)) {
            setThreeDots(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutsidethreeDots, true);
        return () => {
            document.removeEventListener('click', handleClickOutsidethreeDots, true);
        };
    }, []);

    //vertical calender , appointments and Medicine
    const [vertical, setVertical] = useState('Upcoming')

    const toggleVertical = (item) => {
        setVertical(item)
    }

    return (
        <Page
      pageContent={(
        <>
            <div className=' min-h-screen h-[100%]'>

               

                <div className='flex'>
                    {/* background */}
                    <div className='bg-[#FEF8FD] h-[100%] flex flex-row'>

                        {/* post */}
                        <div className='flex flex-col w-[65%] mx-[5%]'>
                            <div className='bg-white h-[24vh] ml-[13%] mt-8 rounded-2xl shadow-xl' >
                                <div className='flex px-10 pt-8 gap-3'>
                                    <img src={account} className='rounded-full w-[8%] h-[60%] shadow-md' />
                                    <input placeholder='Write here...' className='outline-none' />
                                </div>
                                <div className='pt-8 px-10'><hr /></div>
                                <div className='flex pt-4 px-10 justify-between'>
                                    <div className='flex w-[15%] justify-between items-center' >
                                        <TfiGallery color='#C4C4C4' size={18} />
                                        <HiOutlineGif color='#C4C4C4' size={20} />
                                        <HiOutlineLocationMarker color='#C4C4C4' size={20} />
                                        <GrEmoji color='#C4C4C4' size={20} />
                                    </div>
                                    <div className='bg-[#efc419] text-white p-0.5 px-6 rounded-xl' >Post</div>
                                </div>

                            </div>


                            <div className='h-[88vh]  mt-8 ml-[13%] bg-white rounded-2xl shadow-xl' >
                                {/* inner container */}
                                <div className='h-[20%] px-10 flex items-center' >
                                    <FlippingImage />

                                    <div className='flex px-3 w-full justify-between' >

                                        <div>
                                            <div className='flex w-[110%] justify-between items-center' >
                                                <h1 className='font-semibold' >Sierra Ferguson</h1>
                                                <p className='text-xs text-[#7E7E7E]' >1 Day ago 12:45 PM</p>
                                            </div>

                                            <h1 className='text-xs bg-[#efc4194f] w-max p-1 rounded-xl' >Blogger</h1>
                                        </div>

                                        <div className='flex items-center relative' >
                                            <div onClick={threeDotsToggle}><BsThreeDotsVertical /></div>

                                            {threeDots && (<div className='z-10 w-max h-max bg-white  shadow-2xl absolute top-10 text-center' ref={threeDotsOutClick}>
                                                <p className='p-2 px-4 hover:bg-[#efc4197c]' >Mute</p>
                                                <p className='p-2 px-4 hover:bg-[#efc4197c]' >Unfollow</p>
                                                <p className='p-2 px-4 hover:bg-[#efc4197c]' >Block</p>
                                                <p className='p-2 px-4 hover:bg-[#efc4197c]' >About this account</p>
                                                <p className='p-2 px-4 hover:bg-[#efc4197c]' >Report</p>
                                            </div>)}

                                        </div>
                                    </div>

                                </div>

                                {/* inner container text */}
                                <div className='px-10'>
                                    <h1 className='text-xl font-semibold'>Cancer Survivor Stories: Bethany</h1>
                                    <p className='py-2'>{para?.length > 250 ? `${para?.slice(0, 250)}.....` : `${para}`}</p>
                                </div>

                                {/* Image */}
                                <div className=' h-[50%]  px-10 '>
                                    <div className='h-full rounded-3xl bg-blue-300'>
                                        <img src={climberEverest} className='object-cover h-full w-full rounded-3xl' />
                                    </div>
                                </div>

                                <div className='px-10 pt-4 flex justify-between'>

                                    <div className='flex items-center gap-8'>
                                        <div onClick={likeButton}>
                                            {heart ? <AiFillHeart size={30} color='red' /> : <AiOutlineHeart size={30} />}
                                        </div>

                                        <FaRegComment size={26} />
                                        <SlPaperPlane size={26} />
                                    </div>

                                    <div className='flex gap-2'>
                                        <BsBookmarkDash size={25} />
                                        <p>Save</p>
                                    </div>

                                </div>
                            </div>

                        </div>
<div className='flex flex-col '>

                        {/* right side */}
                        <div className='w-[90%] pt-8 px-4 h-max relative'>
                            <div>
                                <div className='bg-gradient-to-r from-[#D4F1FF] to-[#FFFFFF] h-[15%] w-full rounded-2xl shadow-xl '>
                                    <img src={premium} className=' h-[100%] w-[60%] top-[0%] left-[43%] relative' />
                                </div>

                                <div className='text-center w-max absolute top-[18%] left-[20%] font-semibold'>
                                    <h1>Try Premium</h1>
                                    <h1>for free</h1>
                                </div>

                                <div className='w-max absolute top-[45%] left-[20%] text-xs text-[#00000073]'>
                                    One month free
                                </div>

                                <div className='w-max absolute top-[68%] left-[15%] bg-gradient-to-r from-[#efc41955] to-[#ed839a54] p-2 px-8 rounded-3xl'>
                                    Try free
                                </div>

                            </div>
                        </div>

                        {/* calender */}
                        <div className=' w-[90%] mt-10 bg-white   rounded-2xl shadow-xl overflow-hidden px-2'>

                            <div className=' pt-2'>
                                <SingleLineCalendar />
                            </div>

                            <div className='p-4'>
                                <hr />
                            </div>

                            <div className='px-3 font-semibold flex justify-between'>
                                <h1 onClick={() => toggleVertical('Upcoming')} 
                                className={vertical === 'Upcoming' ? 'text-black' : 'text-[#C4C4C4]' }>Upcoming</h1>
                                <h1 onClick={() => toggleVertical('Appointment')} 
                                className={vertical === 'Appointment' ? 'text-black' : 'text-[#C4C4C4]' }>Appointment</h1>
                                <h1 onClick={() => toggleVertical('Medicines')} 
                                className={vertical === 'Medicines' ? 'text-black' : 'text-[#C4C4C4]' }>Medicines</h1>
                            </div>

                            <div className=''>
                                <div className='flex flex-col'>
                                    {vertical === 'Upcoming' && 
                                    (<div className='w-full'>
                                        <VerticalSLC />
                                    </div>)}
                                    {vertical === 'Appointment' && 
                                    (<div className='w-full'>
                                        <VerticalAppointment />
                                    </div>)}
                                    {vertical === 'Medicines' && 
                                    (<div className='w-full'>
                                        <VerticalMedicine />
                                    </div>)}

                                    <div className='w-full h-[10%]  top-[90%] bg-white flex justify-center items-center font-semibold'>
                                        <div className='bg-[#c31a7f3c] flex items-center gap-2 pl-2 rounded-2xl'>
                                            <div className='flex px-4 items-center'>
                                                View all
                                                <RiArrowDropDownLine size={30} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
</div>
                    </div>
                </div>

                {/* floating chat */}
                <FloatingChat />
            </div>

         </>   )}/>
    )
}

export default Home