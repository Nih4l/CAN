import React, { useEffect, useState, useRef } from "react";
import { BiBell } from "react-icons/bi";
import { TiTick } from "react-icons/ti";
import { RxCrossCircled } from "react-icons/rx";
import { MdOutlinePersonOutline } from "react-icons/md";
import { CgAdd } from "react-icons/cg";
import { BsThreeDotsVertical } from "react-icons/bs";
import account from "../Photos/account.jpg";
import account2 from "../Photos/account2.jpg";
import SideNav from "./SideNav";
import { Link } from "react-router-dom";
import Home from "../Pages/Home";

const HomeNav = ({}) => {
  const [friend, setFriend] = useState(false);
  const [notification, setNotification] = useState(false);
  const [explore, setExplore] = useState(true);

  const showFriendreq = () => {
    setFriend(!friend);
  };

  const exploreMore = () => {
    setExplore(!explore);
  };

  const notificationToggle = () => {
    setNotification(!notification);
  };

  //outclick from friend req box :- close
  const outclick = useRef(null);

  const handleClickOutside = (event) => {
    if (outclick.current && !outclick.current.contains(event.target)) {
      setFriend(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);

  //outclick from notifiaction box :- close
  const notificationOutclick = useRef(null);

  const handleClickOutsidenotification = (event) => {
    if (
      notificationOutclick.current &&
      !notificationOutclick.current.contains(event.target)
    ) {
      setNotification(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutsidenotification, true);
    return () => {
      document.removeEventListener(
        "click",
        handleClickOutsidenotification,
        true
      );
    };
  }, []);

  //Open upload from side nav

  return (
    <>
      <div className="w-full">{/* <SideNav /> */}</div>

      <div className=" shadow-lg z-10">
        <div className="flex  p-3">
          <div className=" w-[30%]"></div>
          <div className="flex w-[70%] justify-between">
            <div className="w-[50%]">
              <input
                placeholder="Search"
                className=" w-full h-full outline-none rounded-2xl px-4   bg-[#FEF8FD]  "
              />
            </div>
            <div className="flex justify-start w-[24%]">
            <div className=" flex items-center justify-between gap-6 ">
              {/* Icons */}
              <div className="hidden">
                <div className="" onClick={showFriendreq}>
                  <MdOutlinePersonOutline color="#C31A7F" size={22} />
                </div>
                {friend && (
                  <div
                    ref={outclick}
                    className="bg-white w-[20%] h-[80%] z-10 absolute right-[8%] top-[8%] shadow-2xl"
                  >
                    {/* friend req container */}
                    <div>
                      {" "}
                      {/* notifications items */}
                      <div className="flex justify-between px-4 pt-6 items-center">
                        <h2 className="font-semibold">Friend Request</h2>
                        <p className="text-[#EFC319] text-xs">See All</p>
                      </div>
                      <div className="p-4">
                        <hr />
                      </div>
                      {/* friend reqs */}
                      <div className="flex items-center justify-between ">
                        <div className="flex items-center">
                          <div className="w-max px-3">
                            <img
                              src={account}
                              className="rounded-full h-12 w-12"
                            />
                          </div>

                          <div className="">
                            <h1 className="text-sm font-semibold">
                              Sierra Ferguson
                            </h1>
                            <p className="text-xs">Works at National Museum</p>
                          </div>
                        </div>

                        <div className="flex gap-2 px-3">
                          <div className="rounded-full bg-[#4BC2A9]">
                            <TiTick color="white" size={20} />
                          </div>
                          <div>
                            <RxCrossCircled color="red" size={20} />
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3 ">
                        <div className="flex items-center">
                          <div className="w-max px-3">
                            <img
                              src={account}
                              className="rounded-full h-12 w-12"
                            />
                          </div>

                          <div className="">
                            <h1 className="text-sm font-semibold">
                              Sierra Ferguson
                            </h1>
                            <p className="text-xs">Works at National Museum</p>
                          </div>
                        </div>

                        <div className="flex gap-2 px-3">
                          <div className="rounded-full bg-[#4BC2A9]">
                            <TiTick color="white" size={20} />
                          </div>
                          <div>
                            <RxCrossCircled color="red" size={20} />
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3">
                        <div className="flex items-center">
                          <div className="w-max px-3">
                            <img
                              src={account}
                              className="rounded-full h-12 w-12"
                            />
                          </div>

                          <div className="">
                            <h1 className="text-sm font-semibold">
                              Sierra Ferguson
                            </h1>
                            <p className="text-xs">Works at National Museum</p>
                          </div>
                        </div>

                        <div className="flex gap-2 px-3">
                          <div className="rounded-full bg-[#4BC2A9]">
                            <TiTick color="white" size={20} />
                          </div>
                          <div>
                            <RxCrossCircled color="red" size={20} />
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3">
                        <div className="flex items-center">
                          <div className="w-max px-3">
                            <img
                              src={account}
                              className="rounded-full h-12 w-12"
                            />
                          </div>

                          <div className="">
                            <h1 className="text-sm font-semibold">
                              Sierra Ferguson
                            </h1>
                            <p className="text-xs">Works at National Museum</p>
                          </div>
                        </div>

                        <div className="flex gap-2 px-3">
                          <div className="rounded-full bg-[#4BC2A9]">
                            <TiTick color="white" size={20} />
                          </div>
                          <div>
                            <RxCrossCircled color="red" size={20} />
                          </div>
                        </div>
                      </div>
                      <div className="px-4 pt-6 ">
                        <div className="flex justify-between relative items-center">
                          <h2 className="font-semibold">Discovery Mode</h2>

                          <div
                            className={
                              explore
                                ? "bg-gray-300 h-[90%] w-[15%] rounded-xl absolute right-0 flex items-center justify-start"
                                : "bg-[#4BC2A9] h-[90%] w-[15%] rounded-xl absolute right-0 flex items-center justify-end"
                            }
                          >
                            <div
                              className="h-[70%] w-[40%] bg-white rounded-full mx-1"
                              onClick={exploreMore}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {explore && (
                      <div className="flex flex-col items-center h-[40%] justify-center">
                        <p className="text-sm text-[#7E7E7E]">
                          Turn on Discovery mode to start
                        </p>
                        <p className="text-sm text-[#7E7E7E]">
                          adding friends nearby
                        </p>
                        <h1 className="m-5 p-1 px-2 bg-[#EFC319] rounded-3xl text-white">
                          Find friends
                        </h1>
                      </div>
                    )}

                    {!explore && (
                      <>
                        <div className="flex items-center justify-between pt-3 ">
                          <div className="flex items-center">
                            <div className="w-max px-3">
                              <img
                                src={account}
                                className="rounded-full h-12 w-12"
                              />
                            </div>

                            <div className="">
                              <h1 className="text-sm font-semibold">
                                Sierra Ferguson
                              </h1>
                              <p className="text-xs">
                                Works at National Museum
                              </p>
                            </div>
                          </div>

                          <div className="flex gap-2 px-3">
                            <CgAdd color="gray" size={24} />
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-3 ">
                          <div className="flex items-center">
                            <div className="w-max px-3">
                              <img
                                src={account}
                                className="rounded-full h-12 w-12"
                              />
                            </div>

                            <div className="">
                              <h1 className="text-sm font-semibold">
                                Sierra Ferguson
                              </h1>
                              <p className="text-xs">
                                Works at National Museum
                              </p>
                            </div>
                          </div>

                          <div className="flex gap-2 px-3">
                            <CgAdd color="gray" size={24} />
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-3 ">
                          <div className="flex items-center">
                            <div className="w-max px-3">
                              <img
                                src={account}
                                className="rounded-full h-12 w-12"
                              />
                            </div>

                            <div className="">
                              <h1 className="text-sm font-semibold">
                                Sierra Ferguson
                              </h1>
                              <p className="text-xs">
                                Works at National Museum
                              </p>
                            </div>
                          </div>

                          <div className="flex gap-2 px-3">
                            <CgAdd color="gray" size={24} />
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Notification */}
              <div onClick={notificationToggle}>
                <BiBell color="#C31A7F" size={22} />
              </div>
              {notification && (
                <div
                  ref={notificationOutclick}
                  className="bg-white w-[20%] h-[80%] z-10 absolute right-[3%] top-[8%] shadow-2xl pt-6 px-3"
                >
                  {/* notification container */}
                  <div className="flex justify-between">
                    <div className="flex gap-1">
                      <h2 className="font-semibold">Notification </h2>{" "}
                      <p className="text-gray-300">(2)</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <h2 className="text-gray-300">Clear All</h2>
                      <BsThreeDotsVertical />
                    </div>
                  </div>

                  <div className="p-4">
                    <hr />
                  </div>

                  <div className="overflow-auto max-h-[88%] scrollbar-hide">
                    <div className="flex">
                      <img
                        src={account2}
                        className="rounded-full h-12 w-12 mr-2"
                      />
                      <div className=" ">
                        <p className="font-semibold">Iqra Aziz</p>
                        <p className="flex-wrap">sent you a message</p>
                      </div>
                    </div>

                    <div className="flex mt-3">
                      <img
                        src={account2}
                        className="rounded-full h-12 w-12 mr-2"
                      />
                      <div className=" ">
                        <p className="font-semibold">Iqra Aziz</p>
                        <p className="flex-wrap">liked your photo</p>
                      </div>
                    </div>

                    <div className="flex mt-3">
                      <img
                        src={account2}
                        className="rounded-full h-12 w-12 mr-2"
                      />
                      <div className=" ">
                        <p className="font-semibold">Iqra Aziz</p>
                        <p className="flex-wrap">liked your video</p>
                      </div>
                    </div>

                    <div className="flex mt-3">
                      <img
                        src={account2}
                        className="rounded-full h-12 w-12 mr-2"
                      />
                      <div className=" ">
                        <p className="font-semibold">Iqra Aziz</p>
                        <p className="flex-wrap">sent you a message</p>
                      </div>
                    </div>

                    <div className="flex mt-3">
                      <img
                        src={account2}
                        className="rounded-full h-12 w-12 mr-2"
                      />
                      <div className=" ">
                        <p className="font-semibold">Iqra Aziz</p>
                        <p className="flex-wrap">sent you a message</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex ">
                <Link
                  to="/profile"
                  className="flex items-center gap-2"
                >
                  <div className=" flex">
                    <img className="w-9 rounded-full" src={account} />
                  </div>
                  <div className=" font-semibold">Hi Sierra</div>
                </Link>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HomeNav;
