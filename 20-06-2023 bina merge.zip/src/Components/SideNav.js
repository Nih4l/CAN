import React, { useEffect, useRef, useState } from 'react';
import Logo from '../Photos/Logo.png'
import Logo1 from '../Photos/Logo1.png'
import CAN from '../Photos/CAN.png'
import home from '../Photos/home.png'
import meeting from '../Photos/meeting.png'
import chat from '../Photos/chat.png'
import createPost from '../Photos/createPost.svg'
import saved from '../Photos/saved.png'
import healthRec from '../Photos/healthRec.png'
import healthCard from '../Photos/healthCard.png'
import appointment from '../Photos/appointment.png'
import medicine from '../Photos/medicine.png'
import more from '../Photos/more.png'
import { AiOutlineHome } from 'react-icons/ai'
import { MdOutlineCreate } from 'react-icons/md'
import { Link } from 'react-router-dom';
import CreatePost from './CreatePost';
import CANnn from '../Photos/MoreIcons/CANnn.png'
import contact from '../Photos/MoreIcons/contact.png'
import help from '../Photos/MoreIcons/help.png'
import logout from '../Photos/MoreIcons/logout.png'
import setting from '../Photos/MoreIcons/setting.png'
import share from '../Photos/MoreIcons/share.png'
import Home from '../Pages/Home';

const SideNavbar = ({ OpenUpload }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [isiconVisible, setIsiconVisible] = useState(true);
    const [uploadPosts, setUploadPosts] = useState(false)

    const toggleNavbar = () => {
        setIsOpen(!isOpen);
        setIsiconVisible(!isiconVisible)
    };

    const uploadPost = () => {
        setUploadPosts(!uploadPosts)
    }

    function close_createPost() {
        setUploadPosts(!uploadPosts)
    }

    //show more
    const [showmore, setShowmore] = useState(false)

    function showmoreToggle() {
        setShowmore(!showmore)
    }

    //outclick from 
    const showmoreOutclick = useRef(null);

    const handleClickOutsideshowmore = (event) => {
        if (showmoreOutclick.current && !showmoreOutclick.current.contains(event.target)) {
            setShowmore(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutsideshowmore, true);
        return () => {
            document.removeEventListener('click', handleClickOutsideshowmore, true);
        };
    }, []);

    return (
        <>
            <div className={`relative`}>
                {/* Sidebar */}
                <div
                    className={`z-10  flex flex-col justify-between top-0 left-0 h-screen  bg-white shadow-2xl p-4 transition-all duration-300 ${isOpen ? 'translate-x-0' : '-ml-36'}`}>
                    <ul className=''>
                        <li className={isOpen ? `flex flex-row items-center justify-center transition-all duration-500 ${isOpen ? 'translate-x-0' : '-translate-x-36'}` : `ml-36 w-[30%] flex flex-col justify-center items-center transition-all duration-500 ${isOpen ? 'translate-x-36' : '-translate-x-0'}`}>
                            <img src={Logo1} alt='none' className='w-[78px]' />
                            <img src={CAN} alt='none' className='w-[42px]' />
                        </li>
                        <p className={` transition-all duration-1000 text-[#c4c4c4] ${isOpen ? 'pb-8 translate-x-0' : '-translate-x-36 wi'}`} >_____________________________</p>
                        <Link to='/home'> <li className="mb-6 flex items-center gap-3"><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={home} alt='none' /></div>Home </li></Link>
                        <Link to='/meeting'> <li className="mb-6 flex items-center gap-3"><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={meeting} alt='none' /></div>Meeting </li></Link>
                        <Link to='/chatpage'> <li className="mb-6 flex items-center gap-3"><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={chat} alt='none' /></div>Chat </li></Link>
                        <li className="mb-6 flex items-center gap-3" onClick={uploadPost}><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={createPost} alt='none' /></div>Create Post </li>
                        {/* <li className="mb-6 flex items-center gap-3" onClick={open_post} ><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={createPost} /></div>Create Post </li> */}

                        <Link to='/profile'><li className="mb-6 flex items-center gap-3" ><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={saved} alt='none' /></div>Saved </li></Link>

                        <h1 className='flex flex-row gap-1 pb-4'><p className={`transition-all duration-500  ${!isOpen ? 'translate-x-36 pt-4 ' : 'flex flex-row gap-1 -translate-x-0'}`}>Medical</p> <p>Records</p></h1>


                        <Link to='/HealthRecord'><li className="mb-6 flex items-center gap-3" ><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={healthRec} alt='none' /></div>Health Record </li></Link>
                        <Link to='/HealthCard'><li className="mb-6 flex items-center gap-3" ><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={healthCard} alt='none' /></div>Health Card </li></Link>
                        <Link to='/Appointment'><li className="mb-6 flex items-center gap-3" ><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={appointment} alt='none' /></div>Appointment </li></Link>
                        <li className="mb-6 flex items-center gap-3" ><div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-2' : '-translate-x-0'}`}><img src={medicine} alt='none' /></div>Medicine </li>

                    </ul>
                    <ul className='relative'>
                        <li>
                            <li className="mb-4 flex items-center gap-3" onClick={showmoreToggle}>
                                <div className={`transition-all duration-500  ${!isOpen ? 'translate-x-40 pt-4' : '-translate-x-0'}`}>
                                    <img src={more} alt='none' />
                                </div>
                                More
                            </li>
                        </li>


                        {showmore && (<div ref={showmoreOutclick} className=' h-max w-max bg-white shadow-2xl absolute bottom-0 left-[120%]  items-center'>

                            <p className='flex pt-3 px-4 text-center w-full font-semibold'>Help and support</p>

                            <p className='flex p-3'>
                                <hr />
                            </p>

                            <p className='flex px-4 py-2 hover:bg-[#efc4197c] gap-2'>
                                <img src={CANnn} alt='none' />
                                About us
                            </p>
                            <p className='flex px-4 py-2 hover:bg-[#efc4197c] gap-2'>
                                <img src={help} alt='none' />
                                Help / Feedback
                            </p>
                            <p className='flex px-4 py-2 hover:bg-[#efc4197c] gap-2'>
                                <img src={contact} alt='none' />
                                Contact Us
                            </p>
                            <p className='flex px-4 py-2 hover:bg-[#efc4197c] gap-2'>
                                <img src={help} alt='none' />
                                Help a friend
                            </p>
                            <p className='flex px-4 py-2 hover:bg-[#efc4197c] gap-2'>
                                <img src={setting} alt='none' />
                                Setting
                            </p>
                            <p className='flex px-4 py-2 pb-4 hover:bg-[#efc4197c] gap-2'>
                                <img src={logout} alt='none' />
                                Logout
                            </p>
                        </div>)}
                    </ul>
                </div>

                {/* Toggle Button */}
                <button
                    className={` absolute z-10 top-3 -right-10 p-2 rounded-lg transition-all duration-300 ${isOpen ? '' : 'translate-x-0'
                        }`}
                    onClick={toggleNavbar}
                >
                    <img src={more} alt='none' />
                </button>

            </div>

            {uploadPosts && (
                <div>
                    <CreatePost
                        close_createPost={close_createPost}
                    />
                </div>
            )}


        </>
    );
};

export default SideNavbar;