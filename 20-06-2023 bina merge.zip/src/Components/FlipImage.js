import React, { useState } from 'react';
import account from '../Photos/account.jpg'
import account2 from '../Photos/account2.jpg'
import Roles_Fighter from '../Photos/Roles_Fighter.png'

const FlippingImage = () => {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleClick = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <div className="w-[8%] h-max rounded-full ">
      <div
        className="transition-transform duration-500 ease-in-out transform hover:rotate-y-180"
        style={{
          transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0)',
        }}
        onClick={handleClick}
      >
        <div className="bg-white rounded-full shadow-md">
          <div className="overflow-hidden">
            <img
              className=" object-fill rounded-full"
              src={isFlipped ? account : account2}
              alt="Image"
            />
          </div>
        </div>
      </div>
    </div>
  );
};


export default FlippingImage;
