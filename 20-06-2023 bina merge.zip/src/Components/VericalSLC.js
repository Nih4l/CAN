import React, { useState } from 'react';
import { AiOutlineLeft } from 'react-icons/ai';
import { AiOutlineRight } from 'react-icons/ai';

const SingleLineCalendar = () => {
  const today = new Date();
  const [currentDate, setCurrentDate] = useState(today.getDate());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dates = [];

  const startOffset = Math.max(currentDate - 3, 1);
  const endOffset = Math.min(currentDate + 3, daysInMonth);
  const startDate = Math.max(startOffset, 1);
  const endDate = Math.min(endOffset, daysInMonth);

  // Populate the dates
  for (let i = startDate; i <= endDate; i++) {
    const date = new Date(currentYear, currentMonth, i);
    const day = daysOfWeek[date.getDay()];
    dates.push({ day, date: i, appointments: ['Appointment'] });
    // Replace ['Appointment 1', 'Appointment 2'] with your actual appointment data
  }

  const goToPrevDate = () => {
    if (currentDate === 1) {
      if (currentMonth === 0) {
        setCurrentMonth(11);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
      setCurrentDate(new Date(currentYear, currentMonth - 1, 0).getDate());
    } else {
      setCurrentDate(currentDate - 1);
    }
  };

  const goToNextDate = () => {
    if (currentDate === daysInMonth) {
      if (currentMonth === 11) {
        setCurrentMonth(0);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
      setCurrentDate(1);
    } else {
      setCurrentDate(currentDate + 1);
    }
  };

  return (
    <div className="flex flex-col space-y-2 w-[100%] ">
      <div className='flex justify-between px-4'>
        <div className="text-lg font-semibold ">
          {new Date(currentYear, currentMonth).toLocaleString('default', {
            month: 'long',
            year: 'numeric',
          })}
        </div>
        <div className="flex items-center gap-2">
          <button className="text-sm text-gray-500 hover:text-gray-700" onClick={goToPrevDate}>
            <AiOutlineLeft />
          </button>
          <button className="text-sm text-gray-500 hover:text-gray-700" onClick={goToNextDate}>
            <AiOutlineRight />
          </button>
        </div>
      </div>
      <div className="flex flex-col justify-between w-[100%] gap-2">
        {dates.map((dateObj, index) => (
          <div
            key={index}
            className={`flex gap-4  px-4 rounded-lg w-[100%] h-12`}
          >
            <div className="text-center w-[20%] ">
              <div className="text-sm">{dateObj.day}</div>
              <div>{dateObj.date === today.getDate() ? today.getDate() : dateObj.date}</div>
            </div>
            <div className={`w-[70%] px-4 flex justify-center items-center ${dateObj.date === today.getDate() ? 'text-black bg-[#F5F5F5]' : 'text-black bg-[#F5F5F5]'}`}>
              {dateObj.appointments.map((appointment, index) => (
                <div key={index} className='flex gap-2 '>
                  <div className='font-bold text-[#C31A7F]'>|</div>
                  {appointment}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SingleLineCalendar;