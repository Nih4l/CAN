import React, { useRef, useState } from 'react'
import { GoFileMedia } from 'react-icons/go'
import { IoMdClose } from 'react-icons/io'
import { GrEmoji } from 'react-icons/gr'
import { TfiGallery } from 'react-icons/tfi'
import { HiOutlineGif } from 'react-icons/hi2'
import { HiOutlineLocationMarker } from 'react-icons/hi'
import account from '../Photos/account.jpg'
import { IoCloseCircleSharp } from 'react-icons/io5';

const CreatePost = ({ close_createPost }) => {

  const [image, setImage] = useState(null);
  const hiddenChooseImage = useRef(null);

  const hideImage = () => {
    setImage(false);
  };

  const uploadImage = () => {
    hiddenChooseImage.current.click();
  };

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    setImage(URL.createObjectURL(file));
  };

  return (
    <>
      <div
        className='fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50'
        style={{ backdropFilter: 'blur(2px)' }}>

        <div className='bg-white h-max w-[40%] rounded-3xl'>
          <div className='flex px-10 items-center pt-6'>
            {!image && (<div className='bg-[#efc41965] shadow-lg px-2 rounded-2xl'>
              #successful
            </div>)}
            {image && (<div className='text-center w-full font-semibold text-lg'>
              Create new post
            </div>)}
            

            <div onClick={close_createPost} className='absolute right-[32%]'>
              <IoMdClose />
            </div>
          </div>


          {image && (
                <div className='relative mx-8 mt-4 rounded-2xl overflow-hidden'>
                  <img src={image} alt='Uploaded' className='h-full w-full' />
                  <button className='absolute top-4 right-4' onClick={hideImage}>
                    <IoCloseCircleSharp color='white' />
                  </button>
                </div>
              )}

              <input
                type='file'
                accept='image/*'
                ref={hiddenChooseImage}
                style={{ display: 'none' }}
                onChange={handleImageUpload}
              />

          <div className='w-full px-10 pt-6 rounded-full overflow-hidden flex gap-4 '>
            <img src={account} className='w-[10%] rounded-full' />

            <div className='flex items-center justify-between w-full'>
              <input placeholder='Write here' className='outline-none' />
              <GrEmoji color='#C4C4C4' size={20} />
            </div>

          </div>

          <div className='pt-5 px-8'>
            <hr />
          </div>

          <div className= 'flex justify-between items-center py-6 px-8'>
            <div className='flex gap-4'>

              <TfiGallery color='#C4C4C4' size={18} onClick={uploadImage} />
              
              <HiOutlineGif color='#C4C4C4' size={20} />
              <HiOutlineLocationMarker color='#C4C4C4' size={20} />
              <GrEmoji color='#C4C4C4' size={20} />
              
            </div>
            {/* <div className='bg-[#efc419d9] text-white px-4 p-2 rounded-2xl'> */}
            <div className={image ? 'bg-[#efc419d9] text-white px-4 p-2 my-2 text-center rounded-2xl' : 'bg-[#efc419d9] text-white px-4 p-2  rounded-2xl'}>
              Post
            </div>
          </div>

        </div>
      </div>
    </>
  )
}

export default CreatePost