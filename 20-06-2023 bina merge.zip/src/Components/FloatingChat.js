import React, { useState } from 'react'
import { BsChat } from 'react-icons/bs'
import account from '../Photos/account.jpg'
import { IoMdClose } from 'react-icons/io'

const FloatingChat = () => {

    const [showChat, setShowChat] = useState(false)

    function toggleChat() {
        setShowChat(!showChat)
    }

    return (
        <>
            <div className="fixed bottom-[10%] right-[4%] m-4" 
            onClick={toggleChat} 
            >
                <div className="bg-[#efc41977] hover:bg-[#EFC319] text-white font-bold p-4 rounded-full"><BsChat size={26} color='black' /></div>
            </div>

            <div className={`fixed z-[10] bottom-[0%] right-[4%] w-[20%] h-[60%] bg-white shadow-2xl border-gray-200 border-2 rounded-3xl transition-all duration-300 ${showChat ? '-translate-y-[5%] ' : 'translate-y-[100%]'}`}>
                <div className=' mt-4 mx-4 '>
                    <div className='relative'>

                        <h1 className='text-center font-semibold'>
                            New message
                        </h1>

                        <div className='absolute top-0 right-0' 
                        onClick={toggleChat}>
                            <IoMdClose />
                        </div>

                    </div>

                    <div className='py-4 px-4'>
                        <hr />
                    </div>

                    <div className='flex gap-2'>

                        <div className='w-[25%] rounded-full overflow-hidden bg-black'>
                            <img src={account} />
                        </div>

                        <div className='w-full'>

                            <div className='flex items-center justify-between'>
                                <h1 className='font-semibold'>Iqra Aziz</h1>
                                <p className='text-xs'>Yesterday</p>
                            </div>

                            <div className='text-sm'>
                                How are you ?
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </>
    )
}

export default FloatingChat